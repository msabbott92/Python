from flask_app import app
from flask_app.controllers import users


from users import User
app = Flask(__name__)



if __name__ == "__main__":
    app.run(debug=True)
