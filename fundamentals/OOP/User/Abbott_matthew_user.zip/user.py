class user: 
    def __init__(self, firstName, lastName, email, age) -> None:
        self.first_name = firstName
        self.last_name = lastName
        self.email = email  
        self.age = age
        self.is_rewards_member = False
        self.gold_card_points = 0 

    def display_info(self):
        print(self.first_name)
        print(self.last_name)
        print(self.email)
        print(self.age)
        print(self.is_rewards_member)
        print(self.gold_card_points)
    
    def enroll(self):
        self.is_rewards_member = True
        self.gold_card_points += 200

    def spend_points(self, amount):
        if self.gold_card_points - amount <= 0:
            print("not enough points")
        else:
            self.gold_card_points -= amount

        


user1 = user("Matthew", "Abbott", "me@email.com", 30)
user2 = user("Dave", "Abbott", "dave@email.com", 35)
user3 = user("Sarah", "Abbott", "sarah@email.com", 28)


user1.enroll()
user1.spend_points(50)
user2.enroll()
user2.spend_points(80)

user1.display_info()

user1.spend_points(170)




